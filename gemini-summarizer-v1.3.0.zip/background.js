// Background Service Worker - 纯文本提交版本

// 监听来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'openGemini') {
    handleOpenGemini(request.data)
      .then(result => sendResponse(result))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

// 处理打开Gemini并提交内容
async function handleOpenGemini(pageContent) {
  try {
    console.log('🚀 开始内容提交流程...');

    const settings = await chrome.storage.sync.get({
      openInBackground: true
    });

    // 第1步：获取当前标签页
    const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    console.log('✅ 步骤1/4: 获取当前标签页成功, TabID:', currentTab.id);
    console.log('   当前URL:', currentTab.url);

    // 检查是否为受限页面
    const url = currentTab.url || '';
    const restrictedPatterns = [
      'chrome://',
      'chrome-extension://',
      'edge://',
      'about:',
      'view-source:',
      'chrome.google.com/webstore',
      'microsoftedge.microsoft.com/addons',
      'data:',
      'devtools://'
    ];

    const isRestricted = restrictedPatterns.some(pattern => url.startsWith(pattern) || url.includes(pattern));

    if (isRestricted) {
      throw new Error('❌ 无法在受保护的页面使用此功能\n\n此页面类型不支持：\n• Chrome内部页面（chrome://）\n• 浏览器扩展商店\n• 扩展程序页面\n• 数据URL（data:）\n\n💡 请在普通网页上使用此扩展');
    }

    // 检查是否为空白页或新标签页
    if (!url || url === 'about:blank' || url === 'chrome://newtab/' || url === 'edge://newtab/') {
      throw new Error('❌ 无法在空白页面使用此功能\n\n💡 请打开一个网页后再使用');
    }

    // 第2步：打开Gemini
    console.log('🌐 步骤2/4: 打开Gemini窗口...');
    const { geminiTab, currentWindow } = await openGeminiWindow(currentTab, settings);
    console.log('✅ 步骤2/4: Gemini窗口打开成功');

    // 第3步：等待Gemini加载
    console.log('⏳ 步骤3/4: 等待Gemini页面加载...');
    await waitForTabLoad(geminiTab.id);
    console.log('✅ 步骤3/4: Gemini页面加载完成');

    // 第4步：提交内容到Gemini
    console.log('📤 步骤4/4: 提交内容到Gemini...');
    await submitContentToGemini(geminiTab.id, pageContent);
    console.log('✅ 步骤4/4: 内容已成功提交到Gemini!');

    // 如果勾选了后台打开，回到原窗口
    if (settings.openInBackground) {
      await chrome.windows.update(currentWindow.id, {
        focused: true
      });
    }

    return {
      success: true,
      message: '✅ 内容已成功提交到Gemini！'
    };
  } catch (error) {
    console.error('❌ 流程失败:', error);
    throw error;
  }
}

// 打开Gemini窗口
async function openGeminiWindow(currentTab, settings) {
  // 获取当前窗口信息
  const currentWindow = await chrome.windows.get(currentTab.windowId);

  // 计算右侧位置
  const newWidth = Math.floor(currentWindow.width / 2);
  const newLeft = currentWindow.left + newWidth;

  // Gemini URL
  const geminiUrl = `https://gemini.google.com/app`;

  // 在右侧创建新窗口
  const newWindow = await chrome.windows.create({
    url: geminiUrl,
    type: 'normal',
    width: newWidth,
    height: currentWindow.height,
    left: newLeft,
    top: currentWindow.top,
    focused: !settings.openInBackground
  });

  // 调整原窗口大小
  await chrome.windows.update(currentWindow.id, {
    width: newWidth,
    left: currentWindow.left
  });

  return {
    geminiTab: newWindow.tabs[0],
    currentWindow: currentWindow
  };
}

// 等待标签页加载完成
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const checkTab = async () => {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === 'complete') {
        // 额外等待3秒确保Gemini完全初始化
        setTimeout(resolve, 3000);
      } else {
        setTimeout(checkTab, 100);
      }
    };
    checkTab();
  });
}

// 提交内容到Gemini
async function submitContentToGemini(tabId, pageContent) {
  try {
    console.log('  📤 准备提交内容...');

    // 构建提示词（包含完整正文）
    const prompt = await buildPromptWithContent(pageContent);

    // 注入提交脚本
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: fillAndSubmit,
      args: [prompt]
    });

    console.log('  ✅ 提交脚本已注入');
  } catch (error) {
    console.error('  ❌ 提交内容失败:', error);
    throw new Error('提交失败: ' + error.message);
  }
}

// 构建包含完整内容的提示词
async function buildPromptWithContent(pageContent) {
  const { title, url, content } = pageContent;

  //  组装正文内容
  let fullText = '';
  if (content && Array.isArray(content)) {
    for (const item of content) {
      if (item.type === 'heading' && item.content) {
        fullText += `\n${'#'.repeat(item.level)} ${item.content}\n\n`;
      } else if (item.type === 'text' && item.content) {
        fullText += `${item.content}\n\n`;
      }
    }
  }

  // 如果内容为空，使用占位符
  if (!fullText.trim()) {
    fullText = '（网页内容提取失败或为空）';
  }

  let prompt = `📄 网页内容分析请求\n\n`;
  prompt += `**标题**: ${title}\n`;
  prompt += `**网址**: ${url}\n`;
  prompt += `**提取时间**: ${new Date().toLocaleString('zh-CN')}\n\n`;
  prompt += `═══════════════════════════════════════\n\n`;
  prompt += `## 📝 网页完整正文\n\n`;
  prompt += fullText;
  prompt += `\n\n═══════════════════════════════════════\n\n`;

  // 获取当前活动的配置
  try {
    const result = await chrome.storage.sync.get({
      promptConfigs: [
        {
          id: 'config-1',
          name: '深度阅读分析',
          prompt: getDefaultPrompt(),
          active: true
        }
      ],
      activeConfigId: 'config-1'
    });

    const activeConfig = result.promptConfigs.find(c => c.id === result.activeConfigId);
    if (activeConfig && activeConfig.prompt) {
      prompt += activeConfig.prompt;
    } else {
      prompt += getDefaultPrompt();
    }
  } catch (error) {
    console.error('❌ 获取配置失败，使用默认提示词:', error);
    prompt += getDefaultPrompt();
  }

  return prompt;
}

// 获取默认提示词
function getDefaultPrompt() {
  return `## 📊 深度分析要求\n\n请使用 **Gemini 2.5 Pro** 模型，基于《如何阅读一本书》的阅读技巧，对上述完整网页内容进行多维度深度分析：\n\n### 1️⃣ 整体理解\n(1) 整体来说，这个网页到底在谈些什么？\n- 你一定要想办法找出这个网页的主题，作者如何依次发展这个主题。\n\n### 2️⃣ 细节分析\n(2) 作者细部说了什么，怎么说的？\n- 找出主要的想法、声明与论点。\n\n### 3️⃣ 合理性评估\n(3) 这个网页说得有道理吗？\n- 评估内容的准确性和逻辑性。\n\n### 4️⃣ 实用价值\n(4) 这个网页跟你有什么关系？\n- 分析其实用价值和对读者的启示。\n\n═══════════════════════════════════════\n\n📝 **请用中文进行全面、深入、结构化的分析。**`;
}

// 填充并提交（注入到Gemini页面执行）
function fillAndSubmit(promptText) {
  console.log('🚀 开始填充内容并自动提交...');
  console.log('📝 提示词长度:', promptText ? promptText.length : 0);

  try {
    // 步骤1: 切换到2.5Pro模型
    console.log('🔄 步骤1: 检查并切换到2.5Pro模型...');
    switchTo25Pro();

    // 步骤2: 填充提示词并提交
    setTimeout(() => {
      console.log('📝 步骤2: 填充提示词到输入框...');
      const inputBox = findInputBox();
      if (!inputBox) {
        console.error('❌ 未找到输入框');
        return;
      }

      inputBox.textContent = promptText;
      inputBox.dispatchEvent(new Event('input', { bubbles: true }));
      inputBox.focus();
      console.log('✅ 提示词已填充');

      // 步骤3: 点击提交按钮
      setTimeout(() => {
        console.log('🚀 步骤3: 查找并点击提交按钮...');
        findAndClickSubmitButton(inputBox);
      }, 1000);
    }, 2000); // 等待模型切换完成

  } catch (error) {
    console.error('❌ 整体流程失败:', error);
  }

  // 辅助函数：切换到2.5Pro
  function switchTo25Pro() {
    try {
      // 查找所有按钮和可能的模型选择器元素
      const allElements = Array.from(document.querySelectorAll('button, div[role="button"], [role="listitem"]'));

      console.log(`🔍 查找模型选择器，共 ${allElements.length} 个元素`);

      // 首先检查是否已经是2.5 Pro
      for (const elem of allElements) {
        const text = elem.textContent || '';

        // 检查是否包含 "推理、数学和编码" 和 "2.5 Pro"
        if (text.includes('推理、数学和编码') && text.includes('2.5') && text.includes('Pro')) {
          console.log('✅ 当前已经是2.5 Pro模型，无需切换');
          console.log('   元素文本:', text.substring(0, 100));
          return;
        }
      }

      // 如果不是2.5 Pro，需要切换
      console.log('⚠️ 当前不是2.5 Pro，尝试切换...');

      // 查找Flash按钮并点击打开菜单
      for (const elem of allElements) {
        const text = elem.textContent || '';

        if (text.includes('Flash') || text.includes('flash') || text.includes('2.0') || text.includes('1.5')) {
          console.log('🔍 发现非Pro模型按钮，点击打开菜单...');
          console.log('   按钮文本:', text.substring(0, 100));
          elem.click();

          // 等待菜单出现，然后选择2.5 Pro
          setTimeout(() => {
            const menuItems = document.querySelectorAll(
              'div[role="listitem"], button, [role="menuitem"], [role="option"], div[role="button"]'
            );
            console.log(`🔍 查找2.5 Pro选项，共 ${menuItems.length} 个候选项`);

            for (const option of menuItems) {
              const optionText = option.textContent || '';

              // 查找包含 "推理、数学和编码" 和 "2.5 Pro" 的选项
              if (optionText.includes('推理、数学和编码') && optionText.includes('2.5') && optionText.includes('Pro')) {
                console.log('✅ 找到2.5 Pro选项，点击选择');
                console.log('   选项文本:', optionText.substring(0, 100));
                console.log('   元素类型:', option.tagName);
                console.log('   role属性:', option.getAttribute('role'));

                // 点击元素
                option.click();

                // 如果点击没反应，尝试触发鼠标事件
                setTimeout(() => {
                  const clickEvent = new MouseEvent('click', {
                    view: window,
                    bubbles: true,
                    cancelable: true
                  });
                  option.dispatchEvent(clickEvent);
                  console.log('✅ 已触发点击事件');
                }, 100);

                return;
              }
            }

            console.warn('⚠️ 未找到2.5 Pro选项，打印所有候选项:');
            menuItems.forEach((item, index) => {
              if (index < 20) { // 打印前20个
                const text = item.textContent?.substring(0, 80) || '';
                console.log(`   [${index}] ${text}`);
              }
            });
          }, 1500); // 等待1.5秒

          return;
        }
      }

      console.log('⚠️ 未找到模型选择器，假设已经是2.5 Pro模型');
    } catch (error) {
      console.error('❌ 切换模型失败:', error);
    }
  }

  // 辅助函数：查找输入框
  function findInputBox() {
    const selectors = [
      '[contenteditable="true"]',
      'rich-textarea [contenteditable="true"]',
      'div[contenteditable="true"][role="textbox"]'
    ];

    for (const selector of selectors) {
      const inputBox = document.querySelector(selector);
      if (inputBox) {
        console.log('✅ 找到输入框:', selector);
        return inputBox;
      }
    }

    console.error('❌ 未找到输入框');
    return null;
  }

  // 辅助函数：查找并点击提交按钮
  function findAndClickSubmitButton(inputBox) {
    console.log('🔍 查找提交按钮（输入框右下角）...');

    const inputRect = inputBox.getBoundingClientRect();
    const buttons = document.querySelectorAll('button');

    let submitButton = null;
    let bestScore = 0;

    for (const btn of buttons) {
      if (btn.disabled) continue;

      const rect = btn.getBoundingClientRect();
      const ariaLabel = btn.getAttribute('aria-label') || '';
      const title = btn.getAttribute('title') || '';
      const hasSvg = btn.querySelector('svg') !== null;

      // 位置检查：在输入框右侧且靠近底部
      const isRightOfInput = rect.left > inputRect.right - 200;
      const isNearBottomOfInput =
        rect.top >= inputRect.bottom - 100 &&
        rect.top <= inputRect.bottom + 100;

      // 属性检查
      const isSubmitButton =
        ariaLabel.includes('发送') ||
        ariaLabel.includes('send') ||
        ariaLabel.includes('Send') ||
        title.includes('发送');

      // 计算得分
      let score = 0;
      if (isRightOfInput && isNearBottomOfInput) score += 10;
      if (hasSvg) score += 5;
      if (isSubmitButton) score += 8;
      if (rect.width < 60 && rect.height < 60) score += 3;

      if (score > bestScore) {
        bestScore = score;
        submitButton = btn;
      }
    }

    if (submitButton && bestScore > 10) {
      console.log(`✅ 找到最佳提交按钮! 得分: ${bestScore}`);
      submitButton.click();
      console.log('✅ 已点击提交按钮！');
      return true;
    } else {
      console.error('❌ 未找到合适的提交按钮 (最高得分:', bestScore, ')');
      console.log('📝 请手动点击提交按钮');
      return false;
    }
  }
}

// 监听快捷键
chrome.commands.onCommand.addListener(async (command) => {
  if (command === '_execute_action') {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (tab) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ['content-extractor.js']
        });

        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            if (typeof extractPageContent === 'function') {
              return extractPageContent();
            }
          }
        });

        if (results && results[0] && results[0].result) {
          await handleOpenGemini(results[0].result);
        }
      } catch (error) {
        console.error('快捷键执行失败:', error);
      }
    }
  }
});
